/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package livraria;

import interfaces.TelaPrincipal;

/**
 *
 * @author matheus.souza
 */
public class Livraria {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		TelaPrincipal tela = new TelaPrincipal();
		tela.setTitle("Livraria");
		tela.setResizable(false);
		tela.setLocationRelativeTo(null);
		tela.setVisible(true);
	}
	
}
