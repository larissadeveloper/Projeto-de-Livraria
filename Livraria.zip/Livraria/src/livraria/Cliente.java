/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package livraria;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Vector;

/**
 *
 * @author matheus.souza
 */
public class Cliente {
	
	private long ClienteCPF;
	private String ClienteNome;
	private Date ClienteDataNascto;
	private String ClienteFone;
	private String ClienteEmail;
	
	public Cliente() {
	}

	public Cliente(long ClienteCPF, String ClienteNome, Date ClienteDataNascto, String ClienteFone, String ClienteEmail) {
		this.ClienteCPF = ClienteCPF;
		this.ClienteNome = ClienteNome;
		this.ClienteDataNascto = ClienteDataNascto;
		this.ClienteFone = ClienteFone;
		this.ClienteEmail = ClienteEmail;
	}

	public long getClienteCPF() {
		return ClienteCPF;
	}

	public void setClienteCPF(long ClienteCPF) {
		this.ClienteCPF = ClienteCPF;
	}

	public String getClienteNome() {
		return ClienteNome;
	}

	public void setClienteNome(String ClienteNome) {
		this.ClienteNome = ClienteNome;
	}

	public Date getClienteDataNascto() {
		return ClienteDataNascto;
	}

	public void setClienteDataNascto(Date ClienteDataNascto) {
		this.ClienteDataNascto = ClienteDataNascto;
	}

	public String getClienteFone() {
		return ClienteFone;
	}

	public void setClienteFone(String ClienteFone) {
		this.ClienteFone = ClienteFone;
	}

	public String getClienteEmail() {
		return ClienteEmail;
	}

	public void setClienteEmail(String ClienteEmail) {
		this.ClienteEmail = ClienteEmail;
	}

	public Vector<Livro> getFilterLivros(String filtro) {
		ResultSet rst = null;
		Vector<Cliente> Clientes = new Vector<Cliente>(9999);
		
		Conexao con = new Conexao("localhost","Livraria","sa","mdb123","");
		
		if(con.conectar()) {
			
				String comando = "SELECT ClienteCPF, ClienteNome, ClienteDataNascto, ClienteFone, ClienteEmail FROM Cliente WHERE ClienteNome like ?";
			
			try {
				//Statement stmt = (Statement) con.getCon().createStatement();
				//rst = stmt.executeQuery(comando);
				
				PreparedStatement stmt = con.getCon().prepareStatement(comando);
				stmt.setString(1, "%"+filtro+"%");
				rst = stmt.executeQuery();
				
				Livro livro = null;
				while(rst.next()) {
					cliente = new Cliente(rst.getString("ClienteCPF"),rst.getString("ClienteNome"));
					Clientes.add(cliente);
				}
				
				stmt.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		return Livros;
	}
}
