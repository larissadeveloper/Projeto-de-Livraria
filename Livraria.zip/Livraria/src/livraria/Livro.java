/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package livraria;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;

/**
 *
 * @author matheus.souza
 */
public class Livro {
	
	private long LivroID;
	private String LivroNome;
	private int LivroQtde;
	private double LivroValor;
	
	public Livro() {
	}

	public Livro(long LivroID, String LivroNome, int LivroQtde, double LivroValor) {
		this.LivroID = LivroID;
		this.LivroNome = LivroNome;
		this.LivroQtde = LivroQtde;
		this.LivroValor = LivroValor;
	}

	public long getLivroID() {
		return LivroID;
	}

	public void setLivroID(long LivroID) {
		this.LivroID = LivroID;
	}

	public String getLivroNome() {
		return LivroNome;
	}

	public void setLivroNome(String LivroNome) {
		this.LivroNome = LivroNome;
	}

	public int getLivroQtde() {
		return LivroQtde;
	}

	public void setLivroQtde(int LivroQtde) {
		this.LivroQtde = LivroQtde;
	}

	public double getLivroValor() {
		return LivroValor;
	}

	public void setLivroValor(double LivroValor) {
		this.LivroValor = LivroValor;
	}
	
	public Vector<Livro> getFilterLivros(String filtro) {
		ResultSet rst = null;
		Vector<Livro> Livros = new Vector<Livro>(9999);
		
		Conexao con = new Conexao("localhost","Livraria","sa","mdb123","");
		
		if(con.conectar()) {
			
			String comando = "SELECT LivroID, LivroNome, LivroQtde, LivroValor FROM Livro WHERE LivroNome like ?";
			
			try {
				//Statement stmt = (Statement) con.getCon().createStatement();
				//rst = stmt.executeQuery(comando);
				
				PreparedStatement stmt = con.getCon().prepareStatement(comando);
				stmt.setString(1, "%"+filtro+"%");
				rst = stmt.executeQuery();
				
				Livro livro = null;
				while(rst.next()) {
					livro = new Livro(rst.getInt("LivroID"),rst.getString("LivroNome"),rst.getInt("LivroQtde"),rst.getDouble("LivroValor"));
					Livros.add(livro);
				}
				
				stmt.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		return Livros;
	}
	
	public Vector<Livro> getLivros() {
		ResultSet rst = null;
		Vector<Livro> Livros = new Vector<Livro>(9999);
		
		Conexao con = new Conexao("localhost","Livraria","sa","mdb123","");
		
		if(con.conectar()) {
			
			String comando = "SELECT LivroID, LivroNome, LivroQtde, LivroValor FROM Livro";
			
			try {
				Statement stmt = (Statement) con.getCon().createStatement();
				rst = stmt.executeQuery(comando);
				
				Livro livro = null;
				while(rst.next()) {
					livro = new Livro(rst.getInt("LivroID"),rst.getString("LivroNome"),rst.getInt("LivroQtde"),rst.getDouble("LivroValor"));
					Livros.add(livro);
				}
				
				stmt.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		return Livros;
	}
	
	public void insertLivros() {
		long id = getNextID();
		
		Conexao con = new Conexao("localhost","Livraria","sa","mdb123","");
		
		if(con.conectar()) {
			String comando = "INSERT INTO Livro (LivroID, LivroNome, LivroQtde, LivroValor) VALUES (?, ?, ?, ?)";
			
			try {
				PreparedStatement stmt = con.getCon().prepareStatement(comando);
				stmt.setLong(1, id);
				stmt.setString(2, this.LivroNome);
				stmt.setInt(3, this.LivroQtde);
				stmt.setDouble(4, this.LivroValor);
				stmt.execute();
				stmt.close();
				
			} catch(Exception e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		}
	}
	
	private long getNextID() {
		ResultSet rst = null;
		long id = 1;
		
		Conexao con = new Conexao("localhost","Livraria","sa","mdb123","");
		
		if(con.conectar()) {
			String comando = "SELECT max(LivroID) as LivroID FROM Livro";
			
			try {
				Statement stmt = (Statement) con.getCon().createStatement();
				rst = stmt.executeQuery(comando);
				
				System.out.println(""+id);
				
				while(rst.next()) {
					id += rst.getInt("LivroID");
				}
				
				System.out.println(""+id);
				
				stmt.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		return id;
	}
}
