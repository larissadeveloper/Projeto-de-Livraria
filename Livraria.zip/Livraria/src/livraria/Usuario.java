/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package livraria;

/**
 *
 * @author matheus.souza
 */
public class Usuario {
	
	private int UsuarioCodigo;
	private String UsuarioNome;
	private String UsuarioSenha;

	public Usuario() {
	}

	public Usuario(int UsuarioCodigo, String UsuarioNome, String UsuarioSenha) {
		this.UsuarioCodigo = UsuarioCodigo;
		this.UsuarioNome = UsuarioNome;
		this.UsuarioSenha = UsuarioSenha;
	}

	public int getUsuarioCodigo() {
		return UsuarioCodigo;
	}

	public void setUsuarioCodigo(int UsuarioCodigo) {
		this.UsuarioCodigo = UsuarioCodigo;
	}

	public String getUsuarioNome() {
		return UsuarioNome;
	}

	public void setUsuarioNome(String UsuarioNome) {
		this.UsuarioNome = UsuarioNome;
	}

	public String getUsuarioSenha() {
		return UsuarioSenha;
	}

	public void setUsuarioSenha(String UsuarioSenha) {
		this.UsuarioSenha = UsuarioSenha;
	}
	
}
