/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package livraria;

import java.util.Date;
import java.util.Vector;

/**
 *
 * @author matheus.souza
 */
public class Venda {
	
	private long VendaID;
	private Date VendaData;
	private double VendaValor;
	private long ClienteCPF;
	private String ClienteNome;
	private int UsuarioCodigo;
	private String UsuarioNome;
	private Vector<Livro> Livros;

	public Venda() {
	}

	public Venda(long VendaID, Date VendaData, double VendaValor, long ClienteCPF, String ClienteNome, int UsuarioCodigo, String UsuarioNome) {
		this.VendaID = VendaID;
		this.VendaData = VendaData;
		this.VendaValor = VendaValor;
		this.ClienteCPF = ClienteCPF;
		this.ClienteNome = ClienteNome;
		this.UsuarioCodigo = UsuarioCodigo;
		this.UsuarioNome = UsuarioNome;
	}

	public long getVendaID() {
		return VendaID;
	}

	public void setVendaID(long VendaID) {
		this.VendaID = VendaID;
	}

	public Date getVendaData() {
		return VendaData;
	}

	public void setVendaData(Date VendaData) {
		this.VendaData = VendaData;
	}

	public double getVendaValor() {
		return VendaValor;
	}

	public void setVendaValor(double VendaValor) {
		this.VendaValor = VendaValor;
	}

	public long getClienteCPF() {
		return ClienteCPF;
	}

	public void setClienteCPF(long ClienteCPF) {
		this.ClienteCPF = ClienteCPF;
	}

	public String getClienteNome() {
		return ClienteNome;
	}

	public void setClienteNome(String ClienteNome) {
		this.ClienteNome = ClienteNome;
	}

	public int getUsuarioCodigo() {
		return UsuarioCodigo;
	}

	public void setUsuarioCodigo(int UsuarioCodigo) {
		this.UsuarioCodigo = UsuarioCodigo;
	}

	public String getUsuarioNome() {
		return UsuarioNome;
	}

	public void setUsuarioNome(String UsuarioNome) {
		this.UsuarioNome = UsuarioNome;
	}
	
	public Vector<Livro> getLivros() {
		return Livros;
	}

	public void setLivros(Vector<Livro> Livros) {
		this.Livros = Livros;
	}
	
	
	
}
