/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package livraria;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author matheus.souza
 */
public class Conexao {
	
	String ip;
	String nomeBanco;
	String usuario;
	String senha;
	String tipo;
	Connection con = null;
	
	public Conexao(String ip, String nomeBanco, String usuario, String senha, String tipo) {
		this.ip = ip;
		this.nomeBanco = nomeBanco;
		this.usuario = usuario;
		this.senha = senha;
		this.tipo = tipo;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getNomeBanco() {
		return nomeBanco;
	}

	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public Connection getCon() {
		return con;
	}

	public void setCon(Connection con) {
		this.con = con;
	}
	
	public boolean conectar() {
		boolean isClosed = true;
		
		try {
			String url = "";
			
			url = "jdbc:jtds:sqlserver://"+this.ip+":1433/"+this.nomeBanco;
			Class.forName("net.sourceforge.jtds.jdbc.Driver");
			
			con = DriverManager.getConnection(url, this.usuario, this.senha);
			isClosed = con.isClosed();
			
		} catch(Exception e) {
			System.out.println("Erro - 1: "+e.getMessage());
		}
		
		if(isClosed)
			return false;
		else
			return true;
			
	}
	
	public boolean desconectar() {
		boolean isClosed = false;
		
		try {
			if(!con.isClosed()) {
				con.close();
			}
			
			isClosed = con.isClosed();
		} catch(Exception e) {
			System.out.println("Erro - 2: "+e.getMessage());
		}
		
		return isClosed;
	}
}
